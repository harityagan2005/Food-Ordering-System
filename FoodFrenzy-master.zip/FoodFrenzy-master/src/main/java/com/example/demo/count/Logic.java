package com.example.demo.count;
public class Logic
{
 public static double countTotal(double price,int quantity)
 {
	 double res=price*quantity;
	 return res;
 }
	
}