function enter()
{
	alert("Please login as a user to buy the product")
}